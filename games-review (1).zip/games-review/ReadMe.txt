Instructions to set-up my game reviews website:

To set up the website yopu must first install XAMPP and a browser that supports it,

after isntalling XAMPP you must Instantiate the servers,

the next step would be to type in your URL:localhost(the port number if you have one)/phpmyadmin

The next step would be to import the database by going to application/SQL/games-review.sql

After importing the database you must configure the databse and you should be good to go.


Instructions to set-up chat server:

To start the chat you must first download and install the node.js

after installing node.js you must import the nodes by using npm i socket.io

After doing so you should run start the server by writing node app.js

After the server started you can then go onto chat within the server from which ever browser or account as the admin features are not yet implemented


Instructions for comments:

After you choose a game and click on it to review it, 

if not logged in you should be able to see what comments other users have inputted for each game,

to write a comment the user should be logged in.

right now there are two users within the databse that can be logged in by using cookies

username and password for them are as followed

username:admin      password:admin
username:Lecturer   password:Example 